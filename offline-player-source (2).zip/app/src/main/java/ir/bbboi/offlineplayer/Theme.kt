package ir.bbboi.offlineplayer

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily

// همان پالت radio.html
val Primary = Color(0xFF1A0A31)
val Surface = Color(0xFF241243)
val CardBg = Color(0xFF2D1856)
val Accent = Color(0xFF8B5CF6)
val AccentHover = Color(0xFFA78BFA)
val SubText = Color(0xFFC9C4D8)
val Border = Color(0xFF3D2A64)
val Success = Color(0xFF22C55E)
val Danger = Color(0xFFEF4444)
val Glass = Color(0xD9241243)

// برای فونت وزیرمتن: فایل‌های ttf را در app/src/main/res/font بگذار (مثلاً vazirmatn_regular.ttf)
// و این خط را به FontFamily(Font(R.font.vazirmatn_regular, FontWeight.Normal), Font(R.font.vazirmatn_bold, FontWeight.Bold)) تغییر بده.
val AppFont: FontFamily = FontFamily.Default

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Primary, surface = Surface,
            onSurface = Color.White, onBackground = Color.White,
        ),
    ) {
        ProvideTextStyle(TextStyle(fontFamily = AppFont), content = content)
    }
}
