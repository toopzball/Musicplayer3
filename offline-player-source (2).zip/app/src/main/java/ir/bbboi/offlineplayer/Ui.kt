package ir.bbboi.offlineplayer

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalTime

// ---------------- کمکی‌ها (همان منطق radio.html) ----------------
private val avatarPalette = listOf(
    Color(0xFF8B5CF6), Color(0xFF22C55E), Color(0xFF3B82F6),
    Color(0xFFF59E0B), Color(0xFFEF4444), Color(0xFFEC4899),
)
fun avatarColor(name: String): Color = avatarPalette[name.sumOf { it.code } % avatarPalette.size]
fun toFa(s: String): String = s.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return toFa("%d:%02d".format(s / 60, s % 60))
}

@Composable
fun CircleButton(size: Dp, bg: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(bg)
            .border(1.dp, Border, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun Chip(content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape).background(Glass).border(1.dp, Border, shape)
            .padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        content = content,
    )
}

@Composable
fun StatusDot(playing: Boolean) {
    val t = rememberInfiniteTransition(label = "dot")
    val a by t.animateFloat(1f, 0.4f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a")
    Box(Modifier.size(7.dp).clip(CircleShape).alpha(if (playing) a else 1f).background(if (playing) Success else SubText))
}

// ---------------- صفحهٔ کتابخانه ----------------
@Composable
fun LibraryScreen(
    st: UiState, vm: PlayerViewModel, hasPermission: Boolean,
    onRequestPermission: () -> Unit, onOpenPlayer: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val list = remember(st.tracks, query) {
        if (query.isBlank()) st.tracks
        else st.tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    }
    val current = st.tracks.firstOrNull { it.id == st.currentId }

    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF2A1550), Primary), radius = 1400f))) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(18.dp, 18.dp, 18.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("پلیر آفلاین", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (hasPermission) "${toFa(st.tracks.size.toString())} آهنگ روی گوشی" else "",
                        fontSize = 12.sp, color = SubText,
                    )
                }
                Chip { StatusDot(st.isPlaying); Text("آفلاین", fontSize = 11.sp, color = SubText) }
            }

            if (!hasPermission) {
                Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text("برای خواندن آهنگ‌ها به دسترسی نیاز داریم", color = SubText, fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = onRequestPermission, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                        Text("اجازهٔ دسترسی")
                    }
                }
            } else {
                TextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("جستجوی آهنگ یا خواننده", color = SubText, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, null, tint = SubText) },
                    singleLine = true, shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CardBg, unfocusedContainerColor = CardBg,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = Accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                )
                when {
                    st.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Accent) }
                    list.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Text(if (st.tracks.isEmpty()) "آهنگی پیدا نشد" else "نتیجه‌ای نبود", color = SubText)
                    }
                    else -> LazyColumn(contentPadding = PaddingValues(bottom = if (current != null) 96.dp else 24.dp)) {
                        items(list, key = { it.id }) { t ->
                            TrackRow(t, t.id == st.currentId, st.isPlaying, t.id in st.liked) {
                                vm.play(t.id); onOpenPlayer()
                            }
                        }
                    }
                }
            }
        }

        if (current != null) {
            MiniPlayer(
                current, st.isPlaying, vm::togglePlay, vm::next, onOpenPlayer,
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(14.dp),
            )
        }
    }
}

@Composable
fun TrackRow(t: Track, current: Boolean, playing: Boolean, liked: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (current) CardBg else Color.Transparent)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(avatarColor(t.title)), Alignment.Center) {
            if (current && playing) Icon(Icons.Filled.GraphicEq, null, tint = Color.White)
            else Text(t.title.trim().take(1).uppercase(), fontWeight = FontWeight.Bold, color = Color.White)
        }
        Column(Modifier.weight(1f)) {
            Text(t.title, fontSize = 14.5.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, color = if (current) AccentHover else Color.White)
            Text(t.artist, fontSize = 12.sp, color = SubText, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (liked) Icon(Icons.Filled.Favorite, null, tint = Danger, modifier = Modifier.size(16.dp))
        Text(fmt(t.durationMs), fontSize = 11.sp, color = SubText)
    }
}

@Composable
fun MiniPlayer(
    track: Track, playing: Boolean, onToggle: () -> Unit, onNext: () -> Unit,
    onOpen: () -> Unit, modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier.fillMaxWidth().clip(shape).background(Glass).border(1.dp, Border, shape)
            .clickable(onClick = onOpen).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(avatarColor(track.title)), Alignment.Center) {
            Text(track.title.trim().take(1).uppercase(), fontWeight = FontWeight.Bold, color = Color.White)
        }
        Column(Modifier.weight(1f)) {
            Text(track.title, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, fontSize = 11.5.sp, color = SubText, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        CircleButton(42.dp, Accent, onToggle) {
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White)
        }
        CircleButton(42.dp, CardBg, onNext) { Icon(Icons.Filled.SkipNext, null, tint = Color.White) }
    }
}

// ---------------- صفحهٔ در حال پخش (هم‌دیزاینِ رادیونما) ----------------
@Composable
fun NowPlayingScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val st by vm.state.collectAsState()
    val track = st.tracks.firstOrNull { it.id == st.currentId } ?: return
    BackHandler(onBack = onClose)

    val ctx = LocalContext.current
    val art by produceState<Bitmap?>(null, track.id) { value = withContext(Dispatchers.IO) { loadArt(ctx, track) } }
    val clock by produceState("") {
        while (true) {
            val n = LocalTime.now()
            value = toFa("%02d:%02d".format(n.hour, n.minute)); delay(1000)
        }
    }

    var pos by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(track.id) { while (true) { if (!dragging) pos = vm.position(); delay(400) } }
    val dur = (if (st.durationMs > 0) st.durationMs else track.durationMs).coerceAtLeast(1L)
    val liked = track.id in st.liked

    Box(Modifier.fillMaxSize().background(Primary)) {
        // پس‌زمینهٔ تمام‌صفحه: کاورِ آهنگ + اسکریم
        val bmp = art
        if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF2A1550), Primary), radius = 1400f)), Alignment.Center) {
            Icon(Icons.Filled.MusicNote, null, tint = Color(0x33FFFFFF), modifier = Modifier.size(160.dp))
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            Color(0x8C0A0414), Color(0x400A0414), Color(0x590A0414), Color(0xBF0A0414)))))

        // بالا-راست (در RTL = Start): چیپ وضعیت
        Column(Modifier.align(Alignment.TopStart).statusBarsPadding().padding(18.dp), horizontalAlignment = Alignment.Start,
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip { StatusDot(st.isPlaying); Text(if (st.isPlaying) "در حال پخش" else "پلیر آفلاین", fontSize = 11.sp, color = SubText) }
        }

        // بالا-چپ (= End): ساعت + کادر «بعدی» ۱۵ ثانیهٔ آخر
        Column(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(18.dp).widthIn(max = 220.dp),
            horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip { Text(clock, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            AnimatedVisibility(visible = st.nextTitle != null && dur - pos <= 15_000, enter = fadeIn(), exit = fadeOut()) {
                Column(Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xE6241243))
                    .border(1.dp, Border, RoundedCornerShape(12.dp)).padding(horizontal = 13.dp, vertical = 9.dp)) {
                    Text("بعدی", fontSize = 10.5.sp, color = AccentHover)
                    Text(st.nextTitle.orEmpty(), fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        // پایین: لایک + عنوان + نوار پیشرفت + کنترل‌ها
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(18.dp, 0.dp, 18.dp, 22.dp)) {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircleButton(46.dp, if (liked) Danger else Glass, { vm.toggleLike(track.id) }) {
                    Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "لایک", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text(track.title, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, fontSize = 13.5.sp, color = SubText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Slider(
                value = if (dragging) dragFrac else (pos.toFloat() / dur).coerceIn(0f, 1f),
                onValueChange = { dragging = true; dragFrac = it },
                onValueChangeFinished = { val t = (dragFrac * dur).toLong(); vm.seek(t); pos = t; dragging = false },
                colors = SliderDefaults.colors(thumbColor = AccentHover, activeTrackColor = AccentHover, inactiveTrackColor = Color(0x26FFFFFF)),
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(fmt(if (dragging) (dragFrac * dur).toLong() else pos), fontSize = 11.sp, color = SubText)
                Text(fmt(dur), fontSize = 11.sp, color = SubText)
            }
            Spacer(Modifier.height(10.dp))
            // کنترل‌های مدیا همیشه LTR
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                    IconButton(vm::toggleShuffle) {
                        Icon(Icons.Filled.Shuffle, "پخش تصادفی", tint = if (st.shuffle) AccentHover else Color.White)
                    }
                    IconButton(vm::previous, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipPrevious, "قبلی", tint = Color.White, modifier = Modifier.size(32.dp)) }
                    CircleButton(68.dp, Accent, vm::togglePlay) {
                        Icon(if (st.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "پخش/توقف", tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    IconButton(vm::next, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipNext, "بعدی", tint = Color.White, modifier = Modifier.size(32.dp)) }
                    IconButton(vm::cycleRepeat) {
                        Icon(
                            if (st.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "تکرار",
                            tint = if (st.repeat == Player.REPEAT_MODE_OFF) Color.White else AccentHover,
                        )
                    }
                }
            }
        }

        // برگشت به کتابخانه
        IconButton(onClose, Modifier.align(Alignment.TopCenter).statusBarsPadding()) {
            Icon(Icons.Filled.KeyboardArrowDown, "بستن", tint = Color.White, modifier = Modifier.size(30.dp))
        }
    }
}
