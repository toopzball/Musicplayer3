package ir.bbboi.offlineplayer

import android.app.Application
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File

/** متن کرش را ذخیره می‌کند تا دفعهٔ بعد روی صفحه نمایش داده شود (بدون نیاز به adb). */
object CrashReporter {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    fun install(app: Application) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                file(app).writeText(
                    "Thread: ${t.name}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | ${Build.MANUFACTURER} ${Build.MODEL}\n\n" +
                        Log.getStackTraceString(e)
                )
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? = file(ctx).takeIf { it.exists() }?.readText()
    fun clear(ctx: Context) { file(ctx).delete() }
}
