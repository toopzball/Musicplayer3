package ir.bbboi.offlineplayer

import android.app.Application
import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val tracks: List<Track> = emptyList(),
    val loading: Boolean = true,
    val currentId: Long? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_ALL,
    val liked: Set<Long> = emptySet(),
    val nextTitle: String? = null,
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MusicRepository(app)
    private val prefs = app.getSharedPreferences("player", Context.MODE_PRIVATE)
    private var controller: MediaController? = null
    private var pendingId: Long? = null

    private val _state = MutableStateFlow(
        UiState(liked = prefs.getStringSet("liked", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet())
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                c.repeatMode = Player.REPEAT_MODE_ALL
                sync()
                pendingId?.let { play(it); pendingId = null }
            } catch (e: Exception) {
                android.util.Log.e("PlayerViewModel", "اتصال به سرویس پخش ناموفق بود", e)
            }
        }, ContextCompat.getMainExecutor(app))
    }

    fun load() {
        viewModelScope.launch {
            val t = repo.load()
            _state.update { it.copy(tracks = t, loading = false) }
            sync()
        }
    }

    private fun sync() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        val next = if (c.hasNextMediaItem()) c.getMediaItemAt(c.nextMediaItemIndex).mediaMetadata.title?.toString() else null
        _state.update {
            it.copy(
                currentId = id,
                isPlaying = c.isPlaying,
                durationMs = if (c.duration == C.TIME_UNSET) 0 else c.duration,
                shuffle = c.shuffleModeEnabled,
                repeat = c.repeatMode,
                nextTitle = next,
            )
        }
    }

    fun position(): Long = controller?.currentPosition ?: 0L

    fun play(id: Long) {
        val c = controller
        if (c == null) { pendingId = id; return }
        val tracks = _state.value.tracks
        val idx = tracks.indexOfFirst { it.id == id }
        if (idx < 0) return
        if (c.mediaItemCount != tracks.size) c.setMediaItems(tracks.map(Track::toMediaItem), idx, 0L)
        else c.seekTo(idx, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        when {
            c.mediaItemCount == 0 -> _state.value.tracks.firstOrNull()?.let { play(it.id) }
            c.isPlaying -> c.pause()
            else -> c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
    }

    fun toggleLike(id: Long) {
        val newSet = _state.value.liked.let { if (id in it) it - id else it + id }
        prefs.edit().putStringSet("liked", newSet.map { it.toString() }.toSet()).apply()
        _state.update { it.copy(liked = newSet) }
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
