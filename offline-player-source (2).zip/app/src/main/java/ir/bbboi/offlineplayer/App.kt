package ir.bbboi.offlineplayer

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashReporter.install(this)
    }
}
