package ir.bbboi.offlineplayer

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val ctx: Context) {

    suspend fun load(): List<Track> = withContext(Dispatchers.IO) {
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val result = mutableListOf<Track>()
        ctx.contentResolver.query(
            collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE LOCALIZED ASC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iArtist).orEmpty().let { if (it.isBlank() || it == "<unknown>") "ناشناس" else it }
                result += Track(
                    id = id,
                    title = c.getString(iTitle).orEmpty().ifBlank { "بدون‌نام" },
                    artist = artist,
                    albumId = c.getLong(iAlbum),
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(collection, id),
                )
            }
        }
        result
    }
}

fun loadArt(ctx: Context, t: Track): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.loadThumbnail(t.uri, Size(768, 768), null)
    } else {
        val u = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId)
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
    }
} catch (e: Exception) {
    null
}
